package com.example.jamilsilva.sistemcomp;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.jamilsilva.sistemcomp.dominio.entidades.Ocorrencia;

import java.util.List;

public class OcorrenciaAdapter extends RecyclerView.Adapter<OcorrenciaAdapter.ViewHolderOcorrencia> {

    private List<Ocorrencia> dados;

    public OcorrenciaAdapter(List<Ocorrencia> dados){

        this.dados = dados;
    }

    @Override
    public OcorrenciaAdapter.ViewHolderOcorrencia onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());

        View view = layoutInflater.inflate(R.layout.linha_ocorrencias, parent, false);

        ViewHolderOcorrencia holderOcorrencia = new ViewHolderOcorrencia(view);

        return holderOcorrencia;
    }

    @Override
    public void onBindViewHolder(@NonNull OcorrenciaAdapter.ViewHolderOcorrencia holder, int position) {

        if((dados !=null) && (dados.size() > 0)) {

            Ocorrencia ocorrencia = dados.get(position);

            holder.txtTitulo.setText(ocorrencia.ocorrencia_desc);
            holder.txtSubtit.setText(ocorrencia.ocorrencia_local);
        }

    }

    @Override
    public int getItemCount() {
        return dados.size();
    }

    public class ViewHolderOcorrencia extends RecyclerView.ViewHolder{

        public TextView txtTitulo;
        public TextView txtSubtit;


        public ViewHolderOcorrencia(@NonNull View itemView) {
            super(itemView);

            txtTitulo   = (TextView) itemView.findViewById(R.id.txtOcorrenciaDesc);
            txtSubtit   = (TextView) itemView.findViewById(R.id.txtOccorenciaLocal);
        }
    }
}
