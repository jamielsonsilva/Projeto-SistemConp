package com.example.jamilsilva.sistemcomp;

import android.content.Intent;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.example.jamilsilva.sistemcomp.database.DadosOpenHelperImoveis;
import com.example.jamilsilva.sistemcomp.database.DadosOpenHelperMulta;
import com.example.jamilsilva.sistemcomp.dominio.repositorio.OcorrenciaRepositorio;

public class ActMulta extends AppCompatActivity {

    private RecyclerView lstDados_multa;
    private FloatingActionButton fab_multa;
    private ConstraintLayout layoutContentActCadMulta;

    private SQLiteDatabase conexao;

    private DadosOpenHelperMulta dadosOpenHelperMulta;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_multa);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        fab_multa= (FloatingActionButton)findViewById(R.id.fab_multa);
        lstDados_multa = (RecyclerView)findViewById(R.id.lstDados_multa);

        layoutContentActCadMulta = (ConstraintLayout)findViewById(R.id.layoutContentActCadMulta);

        criarConexao();
    }

    private void criarConexao(){

        try{

            dadosOpenHelperMulta= new DadosOpenHelperMulta(this);

            conexao = dadosOpenHelperMulta.getWritableDatabase();

//            Snackbar.make(layoutContentActCadMulta,"Conexao criada com sucesso!",Snackbar.LENGTH_SHORT)
//                    .setAction("OK",null).show();

            Toast.makeText(this, "Conexão criada com sucesso!", Toast.LENGTH_SHORT).show();

           // ocorrenciaRepositorio = new OcorrenciaRepositorio(conexao);

        }catch (SQLException ex){

            AlertDialog.Builder dlg = new AlertDialog.Builder(this);
            dlg.setTitle("Erro");
            dlg.setMessage(ex.getMessage());
            dlg.setNeutralButton("OK",null);
            dlg.show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == android.R.id.home) {

            this.finish();


        }
        return super.onOptionsItemSelected(item);
    }

    public void TelaCadastMult(View view){
        Intent intent = new Intent(ActMulta.this, ActCadMult.class);
        startActivity(intent);
    }

}
