package com.example.jamilsilva.sistemcomp.dominio.entidades;

import java.util.Date;

public class Ocorrencia {

        public int ocorrencia_cod;
        public String ocorrencia_desc;
        public String ocorrencia_data;
        public String ocorrencia_local;
        public int morador_cod;
}
