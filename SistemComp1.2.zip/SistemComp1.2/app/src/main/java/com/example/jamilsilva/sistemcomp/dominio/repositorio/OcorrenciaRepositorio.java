package com.example.jamilsilva.sistemcomp.dominio.repositorio;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.jamilsilva.sistemcomp.dominio.entidades.Ocorrencia;

import java.sql.ClientInfoStatus;
import java.util.ArrayList;
import java.util.List;

public class OcorrenciaRepositorio {

    private SQLiteDatabase conexao;

    public OcorrenciaRepositorio(SQLiteDatabase conexao){
        this.conexao = conexao;
    }

    public void inserir(Ocorrencia ocorrencia){

        //Recebe os valores que seram enviados para base de dados.
        ContentValues contentValues = new ContentValues();
        //Recebe o nome do campo da tabela seguido do seu valor
        contentValues.put("OCORRENCIA_DESC",ocorrencia.ocorrencia_desc);
        contentValues.put("OCORRENCIA_DATA",ocorrencia.ocorrencia_data);
        contentValues.put("OCORRENCIA_LOCAL",ocorrencia.ocorrencia_local);
        contentValues.put("MORADOR_COD",ocorrencia.morador_cod);

        //Fazer inserção na Base de Dados.
        conexao.insertOrThrow("OCORRENCIA",null,contentValues);
    }

    public void excluir(int ocorrencia_cod){

        String [] parametros = new String[1];
        parametros[0] = String.valueOf(ocorrencia_cod);

        conexao.delete("OCORRENCIA","OCORRENCIA_COD = ?",parametros);
    }

    public void alterar(Ocorrencia ocorrencia){

        //Recebe os valores que seram enviados para base de dados.
        ContentValues contentValues = new ContentValues();
        //Recebe o nome do campo da tabela seguido do seu valor
        contentValues.put("OCORRENCIA_DESC",ocorrencia.ocorrencia_desc);
        contentValues.put("OCORRENCIA_DATA",ocorrencia.ocorrencia_data);
        contentValues.put("OCORRENCIA_LOCAL",ocorrencia.ocorrencia_local);
        contentValues.put("MORADOR_COD",ocorrencia.morador_cod);

        String [] parametros = new String[1];
        parametros[0] = String.valueOf(ocorrencia.ocorrencia_cod);

        conexao.update("OCORRENCIA",contentValues,"OCORRENCIA_COD = ?",parametros);
    }

    public List<Ocorrencia> buscarTodos(){
        //recebe os dados inseridos no banco em uma lista/matriz
        List<Ocorrencia> ocorrencias = new ArrayList<Ocorrencia>();

        //Utilizado para monta uma consulta SQL(StringBuilder)
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT OCORRENCIA_COD, OCORRENCIA_DESC, OCORRENCIA_DATA, OCORRENCIA_LOCAL, MORADOR_COD");
        sql.append("FROM OCORRENCIA");

        //Realiza a consulta (rawQuery ou query)
        //rawQuery = retorna um objeto do tipo Cursor(Lista de registros da base de dados)
        Cursor resultado = conexao.rawQuery(sql.toString(),null);

        //Verifica se retornou algum dado
        if(resultado.getCount() > 0) {
            //Posiciona no primeiro registro da tabela
            resultado.moveToFirst();

            do{

                Ocorrencia ocor = new Ocorrencia();

                ocor.ocorrencia_cod     = resultado.getInt(resultado.getColumnIndexOrThrow("OCORRENCIA_COD"));
                ocor.ocorrencia_desc    = resultado.getString(resultado.getColumnIndexOrThrow("OCORRENCIA_DESC"));
                ocor.ocorrencia_data    = resultado.getString(resultado.getColumnIndexOrThrow("OCORRENCIA_DATA"));
                ocor.ocorrencia_local   = resultado.getString(resultado.getColumnIndexOrThrow("OCORRENCIA_LOCAL"));
                ocor.morador_cod        = resultado.getInt(resultado.getColumnIndexOrThrow("MORADOR_COD"));

                //Adiciona na lista de objetos
                ocorrencias.add(ocor);

                //enquanto tiver resultado move para o prox.
            }while(resultado.moveToNext());





        }

        return ocorrencias;
    }

    public Ocorrencia buscarOcorrencia(int ocorrencia_cod){

        Ocorrencia ocorrencia = new Ocorrencia();

        //Utilizado para monta uma consulta SQL(StringBuilder)
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT OCORRENCIA_COD, OCORRENCIA_DESC, OCORRENCIA_DATA, OCORRENCIA_LOCAL, MORADOR_COD");
        sql.append(" FROM OCORRENCIA");
        sql.append(" WHERE OCORRENCIA_COD = ?");

        String [] parametros = new String[1];
        parametros[0] = String.valueOf(ocorrencia_cod);

        //Realiza a consulta (rawQuery ou query)
        //rawQuery = retorna um objeto do tipo Cursor(Lista de registros da base de dados)
        Cursor resultado = conexao.rawQuery(sql.toString(),parametros);

        //Verifica se retornou algum dado
        if(resultado.getCount() > 0) {
            //Posiciona no primeiro registro da tabela
            resultado.moveToFirst();


            ocorrencia.ocorrencia_cod     = resultado.getInt(resultado.getColumnIndexOrThrow("OCORRENCIA_COD"));
            ocorrencia.ocorrencia_desc    = resultado.getString(resultado.getColumnIndexOrThrow("OCORRENCIA_DESC"));
            ocorrencia.ocorrencia_data    = resultado.getString(resultado.getColumnIndexOrThrow("OCORRENCIA_DATA"));
            ocorrencia.ocorrencia_local   = resultado.getString(resultado.getColumnIndexOrThrow("OCORRENCIA_LOCAL"));
            ocorrencia.morador_cod        = resultado.getInt(resultado.getColumnIndexOrThrow("MORADOR_COD"));

            return ocorrencia;
        }


        return null;
    }
}

