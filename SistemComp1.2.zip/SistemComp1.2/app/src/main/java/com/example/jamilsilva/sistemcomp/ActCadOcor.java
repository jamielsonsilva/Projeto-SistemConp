package com.example.jamilsilva.sistemcomp;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import com.example.jamilsilva.sistemcomp.database.DadosOpenHelperOcorrencia;
import com.example.jamilsilva.sistemcomp.dominio.entidades.Ocorrencia;
import com.example.jamilsilva.sistemcomp.dominio.repositorio.OcorrenciaRepositorio;

import java.sql.SQLException;

public class ActCadOcor extends AppCompatActivity {

    private EditText edtCodigo;
    private EditText edtDescricao;
    private EditText edtData;
    private EditText edtLocal;
    private EditText edtCodMoradorComit;
    private ConstraintLayout layoutContentActCadOcorrencia;


    private OcorrenciaRepositorio ocorrenciaRepositorio;

    private SQLiteDatabase conexao;

    private DadosOpenHelperOcorrencia dadosOpenHelperOcorrencia;

    private Ocorrencia ocorrencia;
    /*
    private RecyclerView lstDados;
    private FloatingActionButton fab;


*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_cad_ocor);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab_ocorrencia);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        edtCodigo = (EditText) findViewById(R.id.edtCodigo);
        edtDescricao = (EditText) findViewById(R.id.edtDescricao);
        edtData = (EditText) findViewById(R.id.edtData);
        edtLocal = (EditText) findViewById(R.id.edtLocal);
        edtCodMoradorComit = (EditText) findViewById(R.id.edtCodMoradorComit);

        layoutContentActCadOcorrencia = (ConstraintLayout) findViewById(R.id.layoutContentActCadOcorrencia);

        criarConexao();

/*        fab = (FloatingActionButton) findViewById(R.id.fab);
        lstDados = (RecyclerView)findViewById(R.id.lstDados);


        //getSupportActionBar().setDisplayShowHomeEnabled(true);
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        layoutContentActCadOcor = (ConstraintLayout) findViewById(R.id.layoutContentActCadOcor);


  */

    }

    private void criarConexao(){

        try{

            dadosOpenHelperOcorrencia = new DadosOpenHelperOcorrencia(this);

            conexao = dadosOpenHelperOcorrencia.getWritableDatabase();

//            Snackbar.make(layoutContentActCadOcorrencia,"Conexao criada com sucesso!",Snackbar.LENGTH_SHORT)
//                    .setAction("OK",null).show();

            Toast.makeText(this, "Conexão criada com sucesso!", Toast.LENGTH_SHORT).show();

            ocorrenciaRepositorio = new OcorrenciaRepositorio(conexao);

        }catch (android.database.SQLException ex){

            AlertDialog.Builder dlg = new AlertDialog.Builder(this);
            dlg.setTitle("Erro");
            dlg.setMessage(ex.getMessage());
            dlg.setNeutralButton("OK",null);
            dlg.show();
        }
    }


    private void confirmar(){

        ocorrencia = new Ocorrencia();

     //   if(validarCampos() == false){

            try {

                ocorrenciaRepositorio.inserir(ocorrencia);

                finish();

            }catch (android.database.SQLException ex){

                AlertDialog.Builder dlg = new AlertDialog.Builder(this);
                dlg.setTitle("Erro");
                dlg.setMessage(ex.getMessage());
                dlg.setNeutralButton("OK",null);
                dlg.show();
            }
       // }
    }


    /*
    private boolean validarCampos(){

        boolean res = false;

        String descricao    = edtDescricao.getText().toString();
        String data         = edtData.getText().toString();
        String local        = edtLocal.getText().toString();
        String codMorador   = edtCodMoradorComit.getText().toString();

        ocorrencia.ocorrencia_desc  = descricao;
        ocorrencia.ocorrencia_data  = data;
        ocorrencia.ocorrencia_local = local;
        ocorrencia.morador_cod      = Integer.parseInt(codMorador);


        if(res = isCampoVazio(descricao)){
            edtDescricao.requestFocus();
        }else
            if(res = isCampoVazio(data)){
                edtData.requestFocus();
            }else
                if(res = isCampoVazio(local)){
                    edtLocal.requestFocus();
                }else
                    if(res = isCampoVazio(codMorador)){
                        edtCodMoradorComit.requestFocus();
                    }

        if(res){
            AlertDialog.Builder dlg = new AlertDialog.Builder(this);
            dlg.setTitle(R.string.title_aviso);
            dlg.setMessage(R.string.message_campos_invalidos_brancos);
            dlg.setNeutralButton(R.string.action_ok,null);
            dlg.show();
        }

        return res;
    }

    private boolean isCampoVazio(String valor){

        boolean resultado = (TextUtils.isEmpty(valor) || valor.trim().isEmpty());
        return resultado;
    }
*/
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_act_cad_ocor, menu);
        return super.onCreateOptionsMenu(menu);
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch (id){

            case R.id.action_salvar_ocor:
                confirmar();
                Toast.makeText(this,"Botão Salvar selecionado", Toast.LENGTH_SHORT).show();

                break;

            case R.id.action_cancelar_ocor:
                this.finish();

                break;

            case android.R.id.home:
                this.finish();

                break;
        }

        return super.onOptionsItemSelected(item);
    }

}
