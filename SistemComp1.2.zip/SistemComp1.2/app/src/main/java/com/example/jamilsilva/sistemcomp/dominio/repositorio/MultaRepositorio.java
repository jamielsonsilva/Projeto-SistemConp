package com.example.jamilsilva.sistemcomp.dominio.repositorio;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.jamilsilva.sistemcomp.dominio.entidades.Multa;

import java.util.ArrayList;
import java.util.List;

public class MultaRepositorio {

    private SQLiteDatabase conexao;

    public MultaRepositorio(SQLiteDatabase conexao){
        this.conexao = conexao;
    }

    public void inserir(Multa multa){

        //Recebe os valores que seram enviados para base de dados.
        ContentValues contentValues = new ContentValues();
        //Recebe o nome do campo da tabela seguido do seu valor
        contentValues.put("MULTA_COD",multa.multa_cod);
        contentValues.put("MULTA_VALOR",multa.multa_valor);
        contentValues.put("MULTA_DATA_VENC",multa.multa_data_venc);
        contentValues.put("MULTA_VALOR_PAGO",multa.multa_valor_pago);
        contentValues.put("MULTA_JUROS",multa.multa_juros);
        contentValues.put("MORADOR_COD",multa.morador_cod);
        contentValues.put("IMOVEL_COD",multa.imovel_cod);



        //Fazer inserção na Base de Dados.
        conexao.insertOrThrow("MULTA",null,contentValues);
    }

    public void excluir(int multa_cod){

        String [] parametros = new String[1];
        parametros[0] = String.valueOf(multa_cod);

        conexao.delete("MULTA","MULTA_COD = ?",parametros);
    }

    public void alterar(Multa multa){

        //Recebe os valores que seram enviados para base de dados.
        ContentValues contentValues = new ContentValues();
        //Recebe o nome do campo da tabela seguido do seu valor
        contentValues.put("MULTA_COD",multa.multa_cod);
        contentValues.put("MULTA_VALOR",multa.multa_valor);
        contentValues.put("MULTA_DATA_VENC",multa.multa_data_venc);
        contentValues.put("MULTA_VALOR_PAGO",multa.multa_valor_pago);
        contentValues.put("MULTA_JUROS",multa.multa_juros);
        contentValues.put("MORADOR_COD",multa.morador_cod);
        contentValues.put("IMOVEL_COD",multa.imovel_cod);

        String [] parametros = new String[1];
        parametros[0] = String.valueOf(multa.multa_cod);

        conexao.update("MULTA",contentValues,"MULTA_COD = ?",parametros);
    }

    public List<Multa> buscarTodos(){
        //recebe os dados inseridos no banco em uma lista/matriz
        List<Multa> multas = new ArrayList<Multa>();

        //Utilizado para monta uma consulta SQL(StringBuilder)
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT MULTA_COD,MULTA_VALOR, MULTA_DATA_VENC, MULTA_VALOR_PAGO, MULTA_JUROS, MORADOR_COD, IMOVEL_COD");
        sql.append("FROM MULTA");

        //Realiza a consulta (rawQuery ou query)
        //rawQuery = retorna um objeto do tipo Cursor(Lista de registros da base de dados)
        Cursor resultado = conexao.rawQuery(sql.toString(),null);

        //Verifica se retornou algum dado
        if(resultado.getCount() > 0) {
            //Posiciona no primeiro registro da tabela
            resultado.moveToFirst();

            do{

                Multa mul = new Multa();

                mul.multa_cod          = resultado.getInt(resultado.getColumnIndexOrThrow("MULTA_COD"));
                mul.multa_valor        = resultado.getFloat(resultado.getColumnIndexOrThrow("MULTA_VALOR"));
                mul.multa_data_venc    = resultado.getString(resultado.getColumnIndexOrThrow("MULTA_DATA_VENC"));
                mul.multa_valor_pago   = resultado.getFloat(resultado.getColumnIndexOrThrow("MULTA_VALOR_PAGO"));
                mul.multa_juros        = resultado.getInt(resultado.getColumnIndexOrThrow("MULTA_JUROS"));
                mul.morador_cod        = resultado.getInt(resultado.getColumnIndexOrThrow("MORADOR_COD"));
                mul.imovel_cod         = resultado.getInt(resultado.getColumnIndexOrThrow("IMOVEL_COD"));

                //Adiciona na lista de objetos
                multas.add(mul);

                //enquanto tiver resultado move para o prox.
            }while(resultado.moveToNext());





        }

        return multas;
    }

    public Multa buscarMulta(int multa_cod){

        Multa multa= new Multa();

        //Utilizado para monta uma consulta SQL(StringBuilder)
        StringBuilder sql = new StringBuilder();

        sql.append("SELECT MULTA_COD,MULTA_VALOR, MULTA_DATA_VENC, MULTA_VALOR_PAGO, MULTA_JUROS, MORADOR_COD, IMOVEL_COD");
        sql.append("FROM MULTA");
        sql.append(" WHERE MULTA_COD = ?");

        String [] parametros = new String[1];
        parametros[0] = String.valueOf(multa_cod);

        //Realiza a consulta (rawQuery ou query)
        //rawQuery = retorna um objeto do tipo Cursor(Lista de registros da base de dados)
        Cursor resultado = conexao.rawQuery(sql.toString(),parametros);

        //Verifica se retornou algum dado
        if(resultado.getCount() > 0) {
            //Posiciona no primeiro registro da tabela
            resultado.moveToFirst();


            multa.multa_cod          = resultado.getInt(resultado.getColumnIndexOrThrow("MULTA_COD"));
            multa.multa_valor        = resultado.getFloat(resultado.getColumnIndexOrThrow("MULTA_VALOR"));
            multa.multa_data_venc    = resultado.getString(resultado.getColumnIndexOrThrow("MULTA_DATA_VENC"));
            multa.multa_valor_pago   = resultado.getFloat(resultado.getColumnIndexOrThrow("MULTA_VALOR_PAGO"));
            multa.multa_juros        = resultado.getInt(resultado.getColumnIndexOrThrow("MULTA_JUROS"));
            multa.morador_cod        = resultado.getInt(resultado.getColumnIndexOrThrow("MORADOR_COD"));
            multa.imovel_cod         = resultado.getInt(resultado.getColumnIndexOrThrow("IMOVEL_COD"));

            return multa;
        }


        return null;
    }
}

