package com.example.jamilsilva.sistemcomp.database;

public class ScriptDLL {

    public static String getCreateTableImovel(){

        StringBuilder sql = new StringBuilder();

        sql.append("CREATE TABLE IF NOT EXISTS IMOVEL(");
        sql.append("IMOVEL_COD INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,");
        sql.append("IMOVEL_DESCR VARCHAR(250),");
        sql.append("IMOVEL_ENDEREÇO VARCHAR(250),");
        sql.append("IMOVEL_SITUACAO VARCHAR(250),");
        sql.append("IMOVEL_VALOR FLOAT,");
        sql.append("IMOVEL_BANHEIRO INT,");
        sql.append("IMOVEL_QUARTO INT,");
        sql.append("IMOVEL_SALA INT);");

        return sql.toString();
    }

    public static String getCreateTableMulta(){

        StringBuilder sql = new StringBuilder();

        sql.append("CREATE TABLE IF NOT EXISTS MULTA(");
        sql.append("MULTA_COD INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,");
        sql.append("MULTA_VALOR FLOAT,");
        sql.append("MULTA_DATA_VENC VARCHAR(11),");
        sql.append("MULTA_VALOR_PAGO FLOAT,");
        sql.append("MULTA_JUROS FLOAT,");
        sql.append("MORADOR_COD INT,");
        sql.append("IMOVEL_COD INT)");

        return sql.toString();
    }

    public static String getCreateTableOcorrencia(){

        StringBuilder sql = new StringBuilder();

        sql.append("CREATE TABLE IF NOT EXISTS OCORRENCIA(");
        sql.append("OCORRENCIA_COD INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,");
        sql.append("OCORRENCIA_DESC VARCHAR(200) NOT NULL,");
        sql.append("OCORRENCIA_DATA VARCHAR(20),");
        sql.append("OCORRENCIA_LOCAL VARCHAR(50),");
        sql.append("MORADOR_COD INTEGER)");

        return sql.toString();
    }

    public static String getCreateTableReserva(){

        StringBuilder sql = new StringBuilder();

        sql.append("CREATE TABLE IF NOT EXISTS RESERVA(");
        sql.append("RESERVA_COD INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,");
        sql.append("RESERVA_DATA_INICIAL VARCHAR(11),");
        sql.append("RESERVA_DATA_FINAL VARCHAR(11),");
        sql.append("AREA_COD INT,");
        sql.append("MORADOR_COD INT)");

        return sql.toString();
    }
}
