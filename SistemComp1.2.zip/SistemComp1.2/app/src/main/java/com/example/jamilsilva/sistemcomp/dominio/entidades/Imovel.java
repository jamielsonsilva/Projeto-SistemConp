package com.example.jamilsilva.sistemcomp.dominio.entidades;

public class Imovel {

        public int imovel_codigo;
        public String imovel_desc;
        public String imovel_endereco;
        public String imovel_situacao;
        public float imovel_valor;
        public int imovel_banheiro;
        public int imovel_quarto;
        public int imovel_sala;
}
