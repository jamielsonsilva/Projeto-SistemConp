package com.example.jamilsilva.sistemcomp;

import android.content.Intent;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.jamilsilva.sistemcomp.database.DadosOpenHelperOcorrencia;

public class ActTelaPrinc extends AppCompatActivity {

    //private SQLiteDatabase conexao;
    //private DadosOpenHelperOcorrencia dadosOpenHelperOcorrencia;
    //private ConstraintLayout layoutContentMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_tela_princ);

    //    layoutContentMain = (ConstraintLayout)findViewById(R.id.layoutContentMain);

  //      criarConexao();
    }
/*
    private void criarConexao(){

        try{

            dadosOpenHelperOcorrencia = new DadosOpenHelperOcorrencia(this);

            conexao = dadosOpenHelperOcorrencia.getWritableDatabase();

            Snackbar.make(layoutContentMain,"Conexao criada com sucesso!",Snackbar.LENGTH_SHORT)
                    .setAction("OK",null).show();

        }catch (SQLException ex){

            AlertDialog.Builder dlg = new AlertDialog.Builder(this);
            dlg.setTitle("Erro");
            dlg.setMessage(ex.getMessage());
            dlg.setNeutralButton("OK",null);
            dlg.show();
        }
    }

*/
    public void TelaImovCadas(View view){
        Intent intent = new Intent(this, ActImov.class);
        startActivity(intent);
    }

    public void TelaMultasCadast(View view) {
        Intent intent2 = new Intent(this, ActMulta.class);
        startActivity(intent2);
    }

    public void TelaAreasCadast(View view){
        Intent intent3 = new Intent(this, ActReser.class);
        startActivity(intent3);
    }

    public void TelaOcorCadast(View view){
        Intent intent4 = new Intent(this, ActOcor.class);
        startActivity(intent4);
    }

}
