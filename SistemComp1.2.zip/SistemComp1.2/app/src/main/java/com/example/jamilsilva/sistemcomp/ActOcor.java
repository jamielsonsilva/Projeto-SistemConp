package com.example.jamilsilva.sistemcomp;

import android.content.Intent;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;

import com.example.jamilsilva.sistemcomp.database.DadosOpenHelperOcorrencia;
import com.example.jamilsilva.sistemcomp.dominio.entidades.Ocorrencia;
import com.example.jamilsilva.sistemcomp.dominio.repositorio.OcorrenciaRepositorio;

import java.util.List;

public class ActOcor extends AppCompatActivity {

    private RecyclerView lstDados_ocorrencia;
    private FloatingActionButton fab_ocorrencia;
    private ConstraintLayout layoutContentActCadOcorrencia;

    private SQLiteDatabase conexao;

    private DadosOpenHelperOcorrencia dadosOpenHelperOcorrencia;

   // private OcorrenciaRepositorio ocorrenciaRepositorio;

   // private OcorrenciaAdapter ocorrenciaAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_ocor);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        fab_ocorrencia = (FloatingActionButton) findViewById(R.id.fab_ocorrencia);
        lstDados_ocorrencia = (RecyclerView)findViewById(R.id.lstDados_ocorrencia);

        layoutContentActCadOcorrencia = (ConstraintLayout)findViewById(R.id.lstDados_ocorrencia);

        //LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        //lstDados_ocorrencia.setLayoutManager(linearLayoutManager);

        //FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
       // getSupportActionBar().setDisplayShowHomeEnabled(true);
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        //ocorrenciaRepositorio   = new OcorrenciaRepositorio(conexao);

        //List<Ocorrencia> dados = ocorrenciaRepositorio.buscarTodos();

        //ocorrenciaAdapter = new OcorrenciaAdapter(dados);

        //lstDados_ocorrencia.setAdapter(ocorrenciaAdapter);

        criarConexao();
    }



    private void criarConexao(){

        try{

            dadosOpenHelperOcorrencia = new DadosOpenHelperOcorrencia(this);

            conexao = dadosOpenHelperOcorrencia.getWritableDatabase();

            Snackbar.make(layoutContentActCadOcorrencia,"Conexao criada com sucesso!",Snackbar.LENGTH_SHORT)
                    .setAction("OK",null).show();


        }catch (SQLException ex){

            AlertDialog.Builder dlg = new AlertDialog.Builder(this);
            dlg.setTitle("Erro");
            dlg.setMessage(ex.getMessage());
            dlg.setNeutralButton("OK",null);
            dlg.show();
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == android.R.id.home) {

            this.finish();


        }
        return super.onOptionsItemSelected(item);
    }

    public void TelaCadastOcor(View view){

        Intent intent = new Intent(ActOcor.this, ActCadOcor.class);
        startActivity(intent);
    }

}
