package com.example.jamilsilva.sistemcomp;

import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import com.example.jamilsilva.sistemcomp.database.DadosOpenHelperMulta;
import com.example.jamilsilva.sistemcomp.dominio.entidades.Multa;
import com.example.jamilsilva.sistemcomp.dominio.entidades.Ocorrencia;
import com.example.jamilsilva.sistemcomp.dominio.repositorio.MultaRepositorio;

public class ActCadMult extends AppCompatActivity {

    private EditText edtCodigo;
    private EditText edtValor;
    private EditText edtVenc;
    private EditText edtValorPago;
    private EditText edtJurosAcres;
    private EditText edtCodMorador;
    private ConstraintLayout layoutContentActCadMulta;

    private MultaRepositorio multaRepositorio;

    private SQLiteDatabase conexao;

    private DadosOpenHelperMulta dadosOpenHelperMulta;

    private Multa multa;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_cad_mult);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab_multa);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        edtCodigo       = (EditText)findViewById(R.id.edtCodigo);
        edtValor        = (EditText)findViewById(R.id.edtValor);
        edtVenc         = (EditText)findViewById(R.id.edtVencimento);
        edtValorPago    = (EditText)findViewById(R.id.edtValorPago);
        edtJurosAcres   = (EditText)findViewById(R.id.edtJurosAcres);
        edtCodMorador   = (EditText)findViewById(R.id.edtCodMoradorMulta);

        layoutContentActCadMulta = (ConstraintLayout)findViewById(R.id.layoutContentActCadMulta);

        criarConexao();


    }

    private void criarConexao(){

        try{

            dadosOpenHelperMulta= new DadosOpenHelperMulta(this);

            conexao = dadosOpenHelperMulta.getWritableDatabase();

            Snackbar.make(layoutContentActCadMulta,"Conexao criada com sucesso!",Snackbar.LENGTH_SHORT)
                    .setAction("OK",null).show();

            multaRepositorio= new MultaRepositorio(conexao);

        }catch (SQLException ex){

            AlertDialog.Builder dlg = new AlertDialog.Builder(this);
            dlg.setTitle("Erro");
            dlg.setMessage(ex.getMessage());
            dlg.setNeutralButton("OK",null);
            dlg.show();
        }
    }

    private void confirmar(){

        multa = new Multa();

        //   if(validarCampos() == false){

        try {

            multaRepositorio.inserir(multa);

            finish();

        }catch (android.database.SQLException ex){

            AlertDialog.Builder dlg = new AlertDialog.Builder(this);
            dlg.setTitle("Erro");
            dlg.setMessage(ex.getMessage());
            dlg.setNeutralButton("OK",null);
            dlg.show();
        }
        // }
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_act_cad_mult, menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch (id){

            case R.id.action_salvar_mult:
                confirmar();
                Toast.makeText(this,"Botão Salvar selecionado", Toast.LENGTH_SHORT).show();

                break;

            case R.id.action_cancelar_mult:

                this.finish();

                break;

            case android.R.id.home:
                this.finish();

                break;
        }

        return super.onOptionsItemSelected(item);
    }


}
