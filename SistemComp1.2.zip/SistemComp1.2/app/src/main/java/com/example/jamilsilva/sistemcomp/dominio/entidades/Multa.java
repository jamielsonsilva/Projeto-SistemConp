package com.example.jamilsilva.sistemcomp.dominio.entidades;

public class Multa {

        public int multa_cod;
        public float multa_valor;
        public String multa_data_venc;
        public float multa_valor_pago;
        public int morador_cod;
        public int imovel_cod;
}
