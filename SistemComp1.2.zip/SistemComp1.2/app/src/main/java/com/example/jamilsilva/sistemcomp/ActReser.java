package com.example.jamilsilva.sistemcomp;

import android.content.Intent;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;

import com.example.jamilsilva.sistemcomp.database.DadosOpenHelperImoveis;
import com.example.jamilsilva.sistemcomp.database.DadosOpenHelperReserva;
import com.example.jamilsilva.sistemcomp.dominio.repositorio.OcorrenciaRepositorio;

public class ActReser extends AppCompatActivity {


    private RecyclerView lstDados_reserva;
    private FloatingActionButton fab_reserva;
    private ConstraintLayout layoutContentActCadReserva;

    private SQLiteDatabase conexao;

    private DadosOpenHelperReserva dadosOpenHelperReserva;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_reser);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        fab_reserva     = (FloatingActionButton)findViewById(R.id.fab_reserva);
        lstDados_reserva= (RecyclerView)findViewById(R.id.lstDados_ocorrencia);

        layoutContentActCadReserva = (ConstraintLayout)findViewById(R.id.layoutContentActCadReserva);
    }

    private void criarConexao(){

        try{

            dadosOpenHelperReserva = new DadosOpenHelperReserva(this);

            conexao = dadosOpenHelperReserva.getWritableDatabase();

            Snackbar.make(layoutContentActCadReserva,"Conexao criada com sucesso!",Snackbar.LENGTH_SHORT)
                    .setAction("OK",null).show();

          //  ocorrenciaRepositorio = new OcorrenciaRepositorio(conexao);

        }catch (SQLException ex){

            AlertDialog.Builder dlg = new AlertDialog.Builder(this);
            dlg.setTitle("Erro");
            dlg.setMessage(ex.getMessage());
            dlg.setNeutralButton("OK",null);
            dlg.show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == android.R.id.home) {

            this.finish();


        }
            return super.onOptionsItemSelected(item);
    }

    public void TelaCadastarArea(View view){

        Intent intent = new Intent(ActReser.this, ActCadReser.class);
        startActivity(intent);
    }

}
