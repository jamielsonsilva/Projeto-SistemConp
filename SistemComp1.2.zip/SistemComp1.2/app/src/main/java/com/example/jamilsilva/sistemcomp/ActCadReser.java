package com.example.jamilsilva.sistemcomp;

import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import com.example.jamilsilva.sistemcomp.database.DadosOpenHelperReserva;
import com.example.jamilsilva.sistemcomp.dominio.entidades.Ocorrencia;
import com.example.jamilsilva.sistemcomp.dominio.entidades.Reserva;
import com.example.jamilsilva.sistemcomp.dominio.repositorio.OcorrenciaRepositorio;
import com.example.jamilsilva.sistemcomp.dominio.repositorio.ReservaRepositorio;

public class ActCadReser extends AppCompatActivity {

    private EditText edtCodigo;
    private EditText edtDataReservaFeita;
    private EditText edtDataReservFinal;
    private EditText edtCodAreaReservada;
    private EditText edtCodMoradorReserva;
    private ConstraintLayout layoutContentActCadReserva;

    private ReservaRepositorio reservaRepositorio;

    private SQLiteDatabase conexao;

    private DadosOpenHelperReserva dadosOpenHelperReserva;

    private Reserva reserva;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_cad_reser);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab_reserva);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        edtCodigo           = (EditText)findViewById(R.id.edtCodigo);
        edtDataReservaFeita = (EditText)findViewById(R.id.edtDataReservaFeita);
        edtDataReservFinal  = (EditText)findViewById(R.id.edtDataReservFinal);
        edtCodAreaReservada = (EditText)findViewById(R.id.edtCodAreaReservada);
        edtCodMoradorReserva= (EditText)findViewById(R.id.edtCodMoradorReserva);

        //layoutContentActCadReserva= (ConstraintLayout)findViewById(R.id.layoutContentActCadReserva);

        criarConexao();

    }

    private void criarConexao(){

        try{

            dadosOpenHelperReserva = new DadosOpenHelperReserva(this);

            conexao = dadosOpenHelperReserva.getWritableDatabase();

//            Snackbar.make(layoutContentActCadReserva,"Conexao criada com sucesso!",Snackbar.LENGTH_SHORT)
//                    .setAction("OK",null).show();

            Toast.makeText(this, "Conexão criada com sucesso!", Toast.LENGTH_SHORT).show();

            reservaRepositorio= new ReservaRepositorio(conexao);

        }catch (SQLException ex){

            AlertDialog.Builder dlg = new AlertDialog.Builder(this);
            dlg.setTitle("Erro");
            dlg.setMessage(ex.getMessage());
            dlg.setNeutralButton("OK",null);
            dlg.show();
        }
    }

    private void confirmar(){

        reserva = new Reserva();

        //   if(validarCampos() == false){

        try {

            reservaRepositorio.inserir(reserva);

            finish();

        }catch (android.database.SQLException ex){

            AlertDialog.Builder dlg = new AlertDialog.Builder(this);
            dlg.setTitle("Erro");
            dlg.setMessage(ex.getMessage());
            dlg.setNeutralButton("OK",null);
            dlg.show();
        }
        // }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_act_cad_reser, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch (id){

            case R.id.action_salvar_reser:
                confirmar();
                Toast.makeText(this,"Botão Salvar selecionado", Toast.LENGTH_SHORT).show();

                break;

            case R.id.action_cancelar_reser:

                this.finish();

                break;

            case android.R.id.home:
                this.finish();

                break;
        }

        return super.onOptionsItemSelected(item);
    }


}
