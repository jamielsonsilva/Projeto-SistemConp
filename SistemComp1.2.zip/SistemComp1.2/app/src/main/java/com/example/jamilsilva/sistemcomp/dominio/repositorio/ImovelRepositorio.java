package com.example.jamilsilva.sistemcomp.dominio.repositorio;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.jamilsilva.sistemcomp.dominio.entidades.Imovel;
import com.example.jamilsilva.sistemcomp.dominio.entidades.Ocorrencia;

import java.util.ArrayList;
import java.util.List;

public class ImovelRepositorio {

    private SQLiteDatabase conexao;

    public ImovelRepositorio(SQLiteDatabase conexao){
        this.conexao = conexao;
    }

    public void inserir(Imovel imovel){

        //Recebe os valores que seram enviados para base de dados.
        ContentValues contentValues = new ContentValues();
        //Recebe o nome do campo da tabela seguido do seu valor
        contentValues.put("IMOVEL_COD",imovel.imovel_codigo);
        contentValues.put("IMOVEL_DESCR",imovel.imovel_desc);
        contentValues.put("IMOVEL_ENDERECO",imovel.imovel_endereco);
        contentValues.put("IMOVEL_SITUACAO",imovel.imovel_situacao);
        contentValues.put("IMOVEL_VALOR",imovel.imovel_valor);
        contentValues.put("IMOVEL_BANHEIRO",imovel.imovel_banheiro);
        contentValues.put("IMOVEL_QUARTO",imovel.imovel_quarto);
        contentValues.put("IMOVEL_SALA",imovel.imovel_sala);





        //Fazer inserção na Base de Dados.
        conexao.insertOrThrow("IMOVEL",null,contentValues);
    }

    public void excluir(int imovel_cod){

        String [] parametros = new String[1];
        parametros[0] = String.valueOf(imovel_cod);

        conexao.delete("IMOVEL","IMOVEL_COD = ?",parametros);
    }

    public void alterar(Imovel imovel){

        //Recebe os valores que seram enviados para base de dados.
        ContentValues contentValues = new ContentValues();
        //Recebe o nome do campo da tabela seguido do seu valor
        contentValues.put("IMOVEL_COD",imovel.imovel_codigo);
        contentValues.put("IMOVEL_DESCR",imovel.imovel_desc);
        contentValues.put("IMOVEL_ENDERECO",imovel.imovel_endereco);
        contentValues.put("IMOVEL_SITUACAO",imovel.imovel_situacao);
        contentValues.put("IMOVEL_VALOR",imovel.imovel_valor);
        contentValues.put("IMOVEL_BANHEIRO",imovel.imovel_banheiro);
        contentValues.put("IMOVEL_QUARTO",imovel.imovel_quarto);
        contentValues.put("IMOVEL_SALA",imovel.imovel_sala);

        String [] parametros = new String[1];
        parametros[0] = String.valueOf(imovel.imovel_codigo);

        conexao.update("IMOVEL",contentValues,"IMOVEL_COD = ?",parametros);
    }

    public List<Imovel> buscarTodos(){
        //recebe os dados inseridos no banco em uma lista/matriz
        List<Imovel> imoveis = new ArrayList<Imovel>();

        //Utilizado para monta uma consulta SQL(StringBuilder)
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT IMOVEL_COD, IMOVEL_DESCR, IMOVEL_ENDERECO, IMOVEL_SITUACAO, IMOVEL_VALOR," +
                " IMOVEL_BANHEIRO, IMOVEL_QUARTO, IMOVEL_SALA");
        sql.append("FROM IMOVEL");

        //Realiza a consulta (rawQuery ou query)
        //rawQuery = retorna um objeto do tipo Cursor(Lista de registros da base de dados)
        Cursor resultado = conexao.rawQuery(sql.toString(),null);

        //Verifica se retornou algum dado
        if(resultado.getCount() > 0) {
            //Posiciona no primeiro registro da tabela
            resultado.moveToFirst();

            do{

                Imovel imo = new Imovel();

                imo.imovel_codigo   = resultado.getInt(resultado.getColumnIndexOrThrow("IMOVEL_COD"));
                imo.imovel_desc     = resultado.getString(resultado.getColumnIndexOrThrow("IMOVEL_DESCR"));
                imo.imovel_endereco = resultado.getString(resultado.getColumnIndexOrThrow("IMOVEL_ENDERECO"));
                imo.imovel_situacao = resultado.getString(resultado.getColumnIndexOrThrow("IMOVEL_SITUACAO"));
                imo.imovel_valor    = resultado.getFloat(resultado.getColumnIndexOrThrow("IMOVEL_VALOR"));
                imo.imovel_banheiro = resultado.getInt(resultado.getColumnIndexOrThrow("IMOVEL_BANHEIRO"));
                imo.imovel_quarto    = resultado.getInt(resultado.getColumnIndexOrThrow("IMOVEL_QUARTO"));
                imo.imovel_sala    = resultado.getInt(resultado.getColumnIndexOrThrow("IMOVEL_SALA"));

                //Adiciona na lista de objetos
                imoveis.add(imo);

                //enquanto tiver resultado move para o prox.
            }while(resultado.moveToNext());





        }

        return imoveis;
    }

    public Imovel buscarImovel(int imovel_cod){

        Imovel imovel = new Imovel();

        //Utilizado para monta uma consulta SQL(StringBuilder)
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT IMOVEL_COD, IMOVEL_DESCR, IMOVEL_ENDERECO, IMOVEL_SITUACAO, IMOVEL_VALOR," +
                " IMOVEL_BANHEIRO, IMOVEL_QUARTO, IMOVEL_SALA");
        sql.append("FROM IMOVEL");
        sql.append(" WHERE IMOVEL_COD = ?");

        String [] parametros = new String[1];
        parametros[0] = String.valueOf(imovel_cod);

        //Realiza a consulta (rawQuery ou query)
        //rawQuery = retorna um objeto do tipo Cursor(Lista de registros da base de dados)
        Cursor resultado = conexao.rawQuery(sql.toString(),parametros);

        //Verifica se retornou algum dado
        if(resultado.getCount() > 0) {
            //Posiciona no primeiro registro da tabela
            resultado.moveToFirst();


            imovel.imovel_codigo   = resultado.getInt(resultado.getColumnIndexOrThrow("IMOVEL_COD"));
            imovel.imovel_desc     = resultado.getString(resultado.getColumnIndexOrThrow("IMOVEL_DESCR"));
            imovel.imovel_endereco = resultado.getString(resultado.getColumnIndexOrThrow("IMOVEL_ENDERECO"));
            imovel.imovel_situacao = resultado.getString(resultado.getColumnIndexOrThrow("IMOVEL_SITUACAO"));
            imovel.imovel_valor    = resultado.getFloat(resultado.getColumnIndexOrThrow("IMOVEL_VALOR"));
            imovel.imovel_banheiro = resultado.getInt(resultado.getColumnIndexOrThrow("IMOVEL_BANHEIRO"));
            imovel.imovel_quarto    = resultado.getInt(resultado.getColumnIndexOrThrow("IMOVEL_QUARTO"));
            imovel.imovel_sala    = resultado.getInt(resultado.getColumnIndexOrThrow("IMOVEL_SALA"));

            return imovel;
        }


        return null;
    }
}

