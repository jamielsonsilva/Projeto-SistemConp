package com.example.jamilsilva.sistemcomp.dominio.entidades;

public class Reserva {

        public int reserva_cod;
        public String reserva_data_inicial;
        public String reserva_data_final;
        public int area_cod;
        public int morador_cod;
}
