package com.example.jamilsilva.sistemcomp.dominio.entidades;

public class Reserva {

        public int reserva_;
        public String ocorrencia_desc;
        public String ocorrencia_data;
        public String ocorrencia_local;
        public int morador_cod;
}

        sql.append("RESERVA_COD INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,");
                sql.append("RESERVA_DATA_INICIAL VARCHAR(11),");
                sql.append("RESERVA_DATA_FINAL VARCHAR(11),");
                sql.append("AREA_COD INT,");
                sql.append("MORADOR_COD INT)");