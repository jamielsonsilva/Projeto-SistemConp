package com.example.jamilsilva.sistemcomp.dominio.repositorio;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.jamilsilva.sistemcomp.dominio.entidades.Reserva;

import java.util.ArrayList;
import java.util.List;

public class ReservaRepositorio {

    private SQLiteDatabase conexao;

    public ReservaRepositorio(SQLiteDatabase conexao){
        this.conexao = conexao;
    }

    public void inserir(Reserva reserva){

        //Recebe os valores que seram enviados para base de dados.
        ContentValues contentValues = new ContentValues();
        //Recebe o nome do campo da tabela seguido do seu valor
        contentValues.put("RESERVA_COD",reserva.reserva_cod);
        contentValues.put("RESERVA_DATA_INICIAL",reserva.reserva_data_inicial);
        contentValues.put("RESERVA_DATA_FINAL",reserva.reserva_data_final);
        contentValues.put("AREA_COD",reserva.area_cod);
        contentValues.put("MORADOR_COD",reserva.morador_cod);

        //Fazer inserção na Base de Dados.
        conexao.insertOrThrow("RESERVA",null,contentValues);
    }

    public void excluir(int reserva_cod){

        String [] parametros = new String[1];
        parametros[0] = String.valueOf(reserva_cod);

        conexao.delete("RESERVA","RESERVA_COD = ?",parametros);
    }

    public void alterar(Reserva reserva){

        //Recebe os valores que seram enviados para base de dados.
        ContentValues contentValues = new ContentValues();
        //Recebe o nome do campo da tabela seguido do seu valor
        contentValues.put("RESERVA_COD",reserva.reserva_cod);
        contentValues.put("RESERVA_DATA_INICIAL",reserva.reserva_data_inicial);
        contentValues.put("RESERVA_DATA_FINAL",reserva.reserva_data_final);
        contentValues.put("AREA_COD",reserva.area_cod);
        contentValues.put("MORADOR_COD",reserva.morador_cod);

        String [] parametros = new String[1];
        parametros[0] = String.valueOf(reserva.reserva_cod);

        conexao.update("RESERVA",contentValues,"RESERVA_COD = ?",parametros);
    }

    public List<Reserva> buscarTodos(){
        //recebe os dados inseridos no banco em uma lista/matriz
        List<Reserva> reservas = new ArrayList<Reserva>();

        //Utilizado para monta uma consulta SQL(StringBuilder)
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT RESERVA_COD, RESERVA_DATA_INICIAL, RESERVA_DATA_FINAL, AREA_COD, MORADOR_COD");
        sql.append("FROM RESERVA");

        //Realiza a consulta (rawQuery ou query)
        //rawQuery = retorna um objeto do tipo Cursor(Lista de registros da base de dados)
        Cursor resultado = conexao.rawQuery(sql.toString(),null);

        //Verifica se retornou algum dado
        if(resultado.getCount() > 0) {
            //Posiciona no primeiro registro da tabela
            resultado.moveToFirst();

            do{

                Reserva res = new Reserva();

                res.reserva_cod             = resultado.getInt(resultado.getColumnIndexOrThrow("RESERVA_COD"));
                res.reserva_data_inicial    = resultado.getString(resultado.getColumnIndexOrThrow("RESERVA_DATA_INICIAL"));
                res.reserva_data_final      = resultado.getString(resultado.getColumnIndexOrThrow("RESERVA_DATA_FINAL"));
                res.area_cod                = resultado.getInt(resultado.getColumnIndexOrThrow("AREA_COD"));
                res.morador_cod             = resultado.getInt(resultado.getColumnIndexOrThrow("MORADOR_COD"));

                //Adiciona na lista de objetos
                reservas.add(res);

                //enquanto tiver resultado move para o prox.
            }while(resultado.moveToNext());





        }

        return reservas;
    }

    public Reserva buscarReserva(int reserva_cod){

        Reserva reserva = new Reserva();

        //Utilizado para monta uma consulta SQL(StringBuilder)
        StringBuilder sql = new StringBuilder();

        sql.append("SELECT RESERVA_COD, RESERVA_DATA_INICIAL, RESERVA_DATA_FINAL, AREA_COD, MORADOR_COD");
        sql.append("FROM RESERVA");
        sql.append(" WHERE RESERVA_COD = ?");

        String [] parametros = new String[1];
        parametros[0] = String.valueOf(reserva_cod);

        //Realiza a consulta (rawQuery ou query)
        //rawQuery = retorna um objeto do tipo Cursor(Lista de registros da base de dados)
        Cursor resultado = conexao.rawQuery(sql.toString(),parametros);

        //Verifica se retornou algum dado
        if(resultado.getCount() > 0) {
            //Posiciona no primeiro registro da tabela
            resultado.moveToFirst();


            reserva.reserva_cod             = resultado.getInt(resultado.getColumnIndexOrThrow("RESERVA_COD"));
            reserva.reserva_data_inicial    = resultado.getString(resultado.getColumnIndexOrThrow("RESERVA_DATA_INICIAL"));
            reserva.reserva_data_final      = resultado.getString(resultado.getColumnIndexOrThrow("RESERVA_DATA_FINAL"));
            reserva.area_cod                = resultado.getInt(resultado.getColumnIndexOrThrow("AREA_COD"));
            reserva.morador_cod             = resultado.getInt(resultado.getColumnIndexOrThrow("MORADOR_COD"));

            return reserva;
        }


        return null;
    }
}

