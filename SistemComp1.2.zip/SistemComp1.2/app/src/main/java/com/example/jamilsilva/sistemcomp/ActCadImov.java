package com.example.jamilsilva.sistemcomp;

import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import com.example.jamilsilva.sistemcomp.database.DadosOpenHelperImoveis;
import com.example.jamilsilva.sistemcomp.dominio.entidades.Imovel;
import com.example.jamilsilva.sistemcomp.dominio.entidades.Multa;
import com.example.jamilsilva.sistemcomp.dominio.repositorio.ImovelRepositorio;

public class ActCadImov extends AppCompatActivity {

    private EditText edtCodigo;
    private EditText edtDescricao;
    private EditText edtEndereco;
    private EditText edtSitucao;
    private EditText edtValor;
    private EditText edtBanheiro;
    private EditText edtSala;
    private EditText edtQuarto;
    private ConstraintLayout layoutContentImovel;

    private ImovelRepositorio imovelRepositorio;

    private SQLiteDatabase conexao;

    private DadosOpenHelperImoveis dadosOpenHelperImoveis;

    private Imovel imovel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_cad_imov);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab_imovel);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        edtCodigo       = (EditText)findViewById(R.id.edtCodigo);
        edtDescricao    = (EditText)findViewById(R.id.edtDescricao);
        edtEndereco     = (EditText)findViewById(R.id.edtEndereco);
        edtSitucao      = (EditText)findViewById(R.id.edtSitucao);
        edtValor        = (EditText)findViewById(R.id.edtValor);
        edtBanheiro     = (EditText)findViewById(R.id.edtBanheiro);
        edtSala         = (EditText)findViewById(R.id.edtSala);
        edtQuarto       = (EditText)findViewById(R.id.edtQuarto);

        layoutContentImovel = (ConstraintLayout)findViewById(R.id.layoutContentImovel);

        criarConexao();


    }

    private void criarConexao(){

        try{

            dadosOpenHelperImoveis = new DadosOpenHelperImoveis(this);

            conexao = dadosOpenHelperImoveis.getWritableDatabase();

            Snackbar.make(layoutContentImovel,"Conexao criada com sucesso!",Snackbar.LENGTH_SHORT)
                    .setAction("OK",null).show();

            imovelRepositorio= new ImovelRepositorio(conexao);

        }catch (SQLException ex){

            AlertDialog.Builder dlg = new AlertDialog.Builder(this);
            dlg.setTitle("Erro");
            dlg.setMessage(ex.getMessage());
            dlg.setNeutralButton("OK",null);
            dlg.show();
        }
    }

    private void confirmar(){

        imovel = new Imovel();

        //   if(validarCampos() == false){

        try {

            imovelRepositorio.inserir(imovel);

            finish();

        }catch (SQLException ex){

            AlertDialog.Builder dlg = new AlertDialog.Builder(this);
            dlg.setTitle("Erro");
            dlg.setMessage(ex.getMessage());
            dlg.setNeutralButton("OK",null);
            dlg.show();
        }
        // }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_act_cad_imov, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch (id){

            case R.id.action_salvar_imov:
                confirmar();
                Toast.makeText(this,"Botão Salvar selecionado", Toast.LENGTH_SHORT).show();

                break;

            case R.id.action_cancelar_imov:

                this.finish();

                break;

            case android.R.id.home:
                this.finish();

                break;
        }

        return super.onOptionsItemSelected(item);
    }


}
